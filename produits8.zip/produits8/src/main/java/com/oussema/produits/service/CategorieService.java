package com.oussema.produits.service;

import java.util.List;

import com.oussema.produits.entities.Categorie;

public interface CategorieService {
	List<Categorie> getAllCategories();

}
